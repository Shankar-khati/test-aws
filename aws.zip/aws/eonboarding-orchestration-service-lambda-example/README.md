# eonboarding-orchestration-service-lambda-example

## Bootstrap CDK
We need to bootstrap cdk before deploy

```shell
npm run cdk bootstrap
```


## deploy Layer
```shell
npm run cdk deploy
```