#!/usr/bin/env node
import 'source-map-support/register'
import * as cdk from 'aws-cdk-lib'
import { EOnboardingOrchestrationServiceLambdaStack } from './stacks/eonboarding-orchestration-service-lambda-example'

const devEnv = {
    account: '385029435447',
    region: 'ap-south-1',
  }

const app = new cdk.App();
new EOnboardingOrchestrationServiceLambdaStack(app, 'EOnboardingOrchestrationServiceLambdaStack', { env: devEnv } )