#!/usr/bin/env node
import 'source-map-support/register'
import * as cdk from 'aws-cdk-lib'
import { EOnboardingOrchestrationServiceLambdaLayerStack } from './stacks/eonboarding-orchestration-service-lambda-layer'


const devEnv = {
    account: '385029435447',
    region: 'ap-south-1',
}

const app = new cdk.App()
new EOnboardingOrchestrationServiceLambdaLayerStack( app, 'EOnboardingOrchestrationServiceLambdaLayer', { env: devEnv } )