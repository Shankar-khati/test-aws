## Bootstrap CDK
We need to bootstrap cdk before deploy

```shell
npm run cdk bootstrap
```


## Build Layer

Use esbuild to compile the JavaScript files for the Layer, deploy the Layer with CDK

```shell
npm run build-layer
cdk deploy
```

## Build Package

```shell
npm run build
```

