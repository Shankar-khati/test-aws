# CDK Lambda Layer Example

This repo is for my [Creating Lambda Layers with TypeScript and CDK - The Right Way](https://www.shawntorsitano.com/2022/06/19/creating-lambda-layers-with-typescript-and-cdk-the-right-way/) post. Refer to that post for information on the code in this repo.